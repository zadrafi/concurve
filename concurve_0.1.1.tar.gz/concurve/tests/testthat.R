library(testthat)
library(concurve)

test_check("concurve")
